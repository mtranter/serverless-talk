"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.questionCreatedHandler = exports.apiHandler = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const XRay = __importStar(require("aws-xray-sdk-core"));
const approvals_routes_1 = require("./approvals-routes");
const approvals_service_1 = require("./approvals-service");
const approvals_repo_1 = require("./approvals-repo");
const dynamoClient = XRay.captureAWSClient(new aws_sdk_1.default.DynamoDB());
exports.apiHandler = approvals_routes_1.routes(approvals_service_1.ApprovalsService(approvals_repo_1.dynamoApprovalsRepo(process.env.APPROVALS_TABLE, process.env.APPROVALS_BY_DATE_INDEX_NAME, dynamoClient)), process.env.CORS_ALLOWED_ORIGINS.split(',').map(o => o.trim()));
const questionCreatedHandler = e => {
    const repo = approvals_repo_1.dynamoApprovalsRepo(process.env.APPROVALS_TABLE, process.env.APPROVALS_BY_DATE_INDEX_NAME, dynamoClient);
    return repo.saveUnapprovedQuestion(e.detail);
};
exports.questionCreatedHandler = questionCreatedHandler;
