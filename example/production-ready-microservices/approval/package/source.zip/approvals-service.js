"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApprovalsService = exports.TalkId = void 0;
exports.TalkId = 'ServerlessTalk-2021-08-26';
const ApprovalsService = (repo) => ({
    approveQuestion: async (id) => {
        const question = await repo.getUnapprovedQuestion(exports.TalkId, id);
        if (question) {
            const savePromise = repo.saveApprovedQuestion(question);
            const deletePromise = repo.deleteUnApprovedQuestion(question);
            await Promise.all([savePromise, deletePromise]);
            return 'OK';
        }
        else {
            return 'NotFound';
        }
    },
    listQuestionsForApproval: () => repo.listUnapprovedQuestions(exports.TalkId),
    listApprovedQuestions: () => repo.listApprovedQuestions(exports.TalkId),
});
exports.ApprovalsService = ApprovalsService;
