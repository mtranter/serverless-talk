"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dynamoApprovalsRepo = void 0;
const funamots_1 = require("funamots");
const buildHashKey = (approved, talkId) => `${approved ? 'APPROVED' : 'UNAPPROVED'}:${talkId}`;
const buildDateRangeKey = (q) => `${q.createDateIso}:${q.id}`;
const buildDto = (approved, q) => ({
    hash: `${approved ? 'APPROVED' : 'UNAPPROVED'}:${q.talkId}`,
    range: q.id,
    lsiRange: buildDateRangeKey(q),
    question: q,
});
const dynamoApprovalsRepo = (tableName, lsiByDateName, client) => {
    const table = funamots_1.Table(tableName, { onEmpty: 'omit' }, client)('hash', 'range');
    const indexedByData = table.lsi(lsiByDateName, 'lsiRange');
    return {
        saveApprovedQuestion: q => {
            return table.put(buildDto(true, q));
        },
        saveUnapprovedQuestion: q => {
            return table.put(buildDto(false, q));
        },
        listApprovedQuestions: talkId => indexedByData.query(`APPROVED:${talkId}`).then(r => r.records.map(r => r.question)),
        listUnapprovedQuestions: talkId => indexedByData.query(`UNAPPROVED:${talkId}`).then(r => r.records.map(r => r.question)),
        getUnapprovedQuestion: (talkId, qId) => table.get({ hash: buildHashKey(false, talkId), range: qId }).then(r => r === null || r === void 0 ? void 0 : r.question),
        deleteUnApprovedQuestion: q => table.delete({ hash: buildHashKey(false, q.talkId), range: q.id }),
    };
};
exports.dynamoApprovalsRepo = dynamoApprovalsRepo;
