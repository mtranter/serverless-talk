"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const approvals_repo_1 = require("./approvals-repo");
const approvals_routes_1 = require("./approvals-routes");
const approvals_service_1 = require("./approvals-service");
const dynamoClient = new aws_sdk_1.DynamoDB({
    endpoint: process.env.MOCK_DYNAMODB_ENDPOINT,
    sslEnabled: false,
    region: 'local',
    credentials: {
        accessKeyId: '1',
        secretAccessKey: '2',
    },
});
const testHandler = (h) => (event) => h(event, null, null);
describe('Questions Routes', () => {
    const repo = approvals_repo_1.dynamoApprovalsRepo('Approvals', 'ApprovalsByDate', dynamoClient);
    const sut = testHandler(approvals_routes_1.routes(approvals_service_1.ApprovalsService(repo), []));
    describe('List unapproved questions', async () => {
        const testMsg = {
            id: '1',
            talkId: approvals_service_1.TalkId,
            text: 'Question 1',
            username: 'jsmith',
            createDateIso: new Date().toISOString(),
        };
        it('should return 200 status and list of results', async () => {
            await repo.saveUnapprovedQuestion(testMsg);
            const result = await sut({
                path: '/approvals/questions/unapproved',
                httpMethod: 'get',
            });
            expect(result.statusCode).toEqual(200);
            expect(JSON.parse(result.body)).toEqual([testMsg]);
        });
    });
    describe('List approved questions', async () => {
        const testMsg = {
            id: '1',
            talkId: approvals_service_1.TalkId,
            text: 'Question 1',
            username: 'jsmith',
            createDateIso: new Date().toISOString(),
        };
        it('should return 200 status and list of results', async () => {
            await repo.saveApprovedQuestion(testMsg);
            const result = await sut({
                path: '/approvals/questions/approved',
                httpMethod: 'get',
            });
            expect(result.statusCode).toEqual(200);
            expect(JSON.parse(result.body)).toEqual([testMsg]);
        });
    });
    describe('E2E Approval flow', () => {
        const testMsg = {
            id: '1',
            talkId: approvals_service_1.TalkId,
            text: 'Question 1',
            username: 'jsmith',
            createDateIso: new Date().toISOString(),
        };
        it('should return 200 status and list of results', async () => {
            await repo.saveUnapprovedQuestion(testMsg);
            const resulApprovedResult = await sut({
                path: '/approvals/questions/approved',
                httpMethod: 'get',
            });
            expect(resulApprovedResult.statusCode).toEqual(200);
            expect(JSON.parse(resulApprovedResult.body)).toEqual([]);
            const unapprovedResult = await sut({
                path: '/approvals/questions/unapproved',
                httpMethod: 'get',
            });
            expect(unapprovedResult.statusCode).toEqual(200);
            expect(JSON.parse(unapprovedResult.body)).toEqual([testMsg]);
            const approveResult = await sut({
                httpMethod: 'put',
                path: `/approvals/questions/${testMsg.id}/approve`,
                pathParameters: {
                    questionId: testMsg.id,
                },
            });
            expect(approveResult.statusCode).toEqual(200);
            const resulApprovedResult2 = await sut({
                path: '/approvals/questions/approved',
                httpMethod: 'get',
            });
            expect(resulApprovedResult2.statusCode).toEqual(200);
            expect(JSON.parse(resulApprovedResult2.body)).toEqual([testMsg]);
        });
    });
});
