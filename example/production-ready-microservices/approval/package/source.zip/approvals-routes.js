"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.routes = void 0;
const ts_lambda_router_1 = require("ts-lambda-router");
const logging_1 = require("./logging");
const routes = (svc, allowedOrigins) => ts_lambda_router_1.LambdaRouter.build(rb => rb
    .put('/approvals/questions/{questionId}/approve')(async (req) => {
    const response = await svc.approveQuestion(req.pathParams.questionId);
    return {
        statusCode: response == 'OK' ? 200 : 404,
        body: { result: response },
    };
})
    .get('/approvals/questions/approved')(() => svc.listApprovedQuestions().then(qs => ({
    statusCode: 200,
    body: qs,
})))
    .get('/approvals/questions/unapproved')(() => svc.listQuestionsForApproval().then(qs => ({
    statusCode: 200,
    body: qs,
}))), {
    logConfig: {
        logRequestBody: true,
        logResponseBody: true,
        logRequests: true,
        logResponses: true,
        logger: logging_1.logger,
    },
    corsConfig: {
        allowHeaders: '*',
        allowMethods: '*',
        allowCredentials: true,
        allowOrigin: allowedOrigins,
    },
});
exports.routes = routes;
