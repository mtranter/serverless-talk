"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const quesions_repo_1 = require("./quesions-repo");
const questions_event_publisher_1 = require("./questions-event-publisher");
const questions_routes_1 = require("./questions-routes");
const questions_service_1 = require("./questions-service");
const dynamoClient = new aws_sdk_1.DynamoDB({
    endpoint: process.env.MOCK_DYNAMODB_ENDPOINT,
    sslEnabled: false,
    region: 'local',
    credentials: {
        accessKeyId: '1',
        secretAccessKey: '2',
    },
});
const putEvents = jest.fn().mockReturnValue({
    promise: () => Promise.resolve(),
});
const testHandler = (h) => (event) => h(event, null, null);
describe('Questions Routes', () => {
    const sut = testHandler(questions_routes_1.routes(questions_service_1.QuestionsService(quesions_repo_1.dynamoQuestionsRepo('Questions', dynamoClient), questions_event_publisher_1.eventBridgePubliser({ putEvents }, 'TestBus')), []));
    describe('POST a new question', () => {
        beforeEach(() => {
            jest.clearAllMocks();
        });
        const testQuestion = {
            text: 'What is the meaning of life?',
            username: 'Lunkwill',
        };
        const postPromise = () => sut({
            path: '/questions',
            body: JSON.stringify(testQuestion),
            httpMethod: 'post',
        });
        it('should return 201 status', async () => {
            const result = await postPromise();
            expect(result.statusCode).toEqual(201);
        });
        it('should save the created question', async () => {
            await postPromise();
            const saved = await dynamoClient
                .query({
                TableName: 'Questions',
                KeyConditionExpression: '#h = :hash and begins_with(#r, :range)',
                ExpressionAttributeValues: {
                    ':hash': { S: 'QUESTION_BY_USERNAME:ServerlessTalk-2021-08-26' },
                    ':range': { S: 'username:Lunkwill:' },
                },
                ExpressionAttributeNames: {
                    '#h': 'hash',
                    '#r': 'range',
                },
            })
                .promise();
            expect(saved.Count).toEqual(1);
            const savedQuestion = saved.Items[0].question;
            expect(savedQuestion.M.text.S).toEqual(testQuestion.text);
            expect(savedQuestion.M.username.S).toEqual(testQuestion.username);
        });
        it('should publish a question created event', async () => {
            await postPromise();
            expect(putEvents).toHaveBeenCalledTimes(1);
            const event = putEvents.mock.calls[0][0];
            const entry = JSON.parse(event.Entries[0].Detail);
            expect(entry).toMatchObject(testQuestion);
        });
    });
    describe('get user questions', () => {
        const fetchResult = () => sut({
            path: '/questions/jsmith',
            httpMethod: 'get',
        });
        it('should return 200 and a list of questions for valid request', async () => {
            const result = await fetchResult();
            expect(result.statusCode).toEqual(200);
            expect(JSON.parse(result.body).length).toEqual(2);
        });
    });
});
