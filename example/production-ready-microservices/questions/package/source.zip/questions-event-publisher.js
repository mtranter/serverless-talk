"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventBridgePubliser = void 0;
const eventBridgePubliser = (eb, eventBusName) => ({
    publishQuestionCreated: q => eb
        .putEvents({
        Entries: [
            {
                Detail: JSON.stringify(q),
                DetailType: 'com.mtranter.serverless-talk.QuestionCreated',
                EventBusName: eventBusName,
                Source: 'com.mtranter.serverless-talk.Questions',
            },
        ],
    })
        .promise()
        .then(() => undefined),
});
exports.eventBridgePubliser = eventBridgePubliser;
