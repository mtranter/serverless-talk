"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.routes = void 0;
const ts_lambda_router_1 = require("ts-lambda-router");
const typebox_1 = require("@sinclair/typebox");
const logging_1 = require("./logging");
const CreateQuestionRequestSchema = typebox_1.Type.Object({
    text: typebox_1.Type.String({ minLength: 5, maxLength: 1000 }),
    username: typebox_1.Type.String({ minLength: 1, maxLength: 250 }),
});
const routes = (svc, allowedOrigins) => ts_lambda_router_1.LambdaRouter.build(rb => rb
    .post('/questions', CreateQuestionRequestSchema)(async (req) => {
    await svc.saveQuestion(req.body);
    return {
        statusCode: 201,
        body: { result: 'Created' },
    };
})
    .get('/questions/{username}')(r => svc.listQuestionsForUser(r.pathParams.username).then(qs => ({
    statusCode: 200,
    body: qs,
}))), {
    logConfig: {
        logRequestBody: true,
        logResponseBody: true,
        logRequests: true,
        logResponses: true,
        logger: logging_1.logger,
    },
    corsConfig: {
        allowHeaders: '*',
        allowMethods: '*',
        allowCredentials: true,
        allowOrigin: allowedOrigins,
    },
});
exports.routes = routes;
