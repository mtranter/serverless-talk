"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dynamoQuestionsRepo = void 0;
const crypto_1 = __importDefault(require("crypto"));
const funamots_1 = require("funamots");
const logging_1 = require("./logging");
const hashValue = (val) => crypto_1.default.createHash('md5').update(val).digest('hex');
const questionByUsernameHashKey = (q) => ({ hash: `QUESTION_BY_USERNAME:${q.talkId}` });
const buildPrimaryKey = (q) => ({
    ...questionByUsernameHashKey(q),
    range: `username:${q.username}:timestamp:${q.createDateIso}:id:${hashValue(q.text)}`,
});
const buildDto = (q) => ({
    ...buildPrimaryKey(q),
    question: q,
});
const dynamoQuestionsRepo = (tableName, client) => {
    const table = funamots_1.Table(tableName, { onEmpty: 'omit' }, client)('hash', 'range');
    return {
        saveQuestion: q => {
            logging_1.logger.info(`Saving question`, q);
            return table.put(buildDto(q));
        },
        listQuestionsForUser: (talkId, username) => table
            .query(talkId, {
            sortKeyExpression: { begins_with: `username:${username}:` },
        })
            .then(r => r.records.map(r => r.question)),
    };
};
exports.dynamoQuestionsRepo = dynamoQuestionsRepo;
