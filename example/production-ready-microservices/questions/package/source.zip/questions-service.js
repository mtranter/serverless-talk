"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuestionsService = void 0;
const uuid_1 = require("uuid");
const TALK_ID = 'ServerlessTalk-2021-08-26';
const QuestionsService = (repo, eventPublisher) => ({
    saveQuestion: q => {
        const question = {
            id: uuid_1.v4(),
            ...q,
            talkId: TALK_ID,
            createDateIso: new Date().toISOString(),
        };
        const savePromise = repo.saveQuestion(question);
        const publishProise = eventPublisher.publishQuestionCreated(question);
        return Promise.all([savePromise, publishProise]).then(() => undefined);
    },
    listQuestionsForUser: u => repo.listQuestionsForUser(TALK_ID, u),
});
exports.QuestionsService = QuestionsService;
